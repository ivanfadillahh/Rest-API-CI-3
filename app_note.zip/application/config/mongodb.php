<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    // LOCAL MONGO ==================
    // $config['host'] = 'localhost';
    // $config['port'] = 27017;
    // $config['username'] = '';
    // $config['password'] = '';
    // $config['authenticate'] = FALSE;

    // PRODUCTION MONGO ==================
    $config['host'] = 'localhost'; 
    $config['port'] = 27017;
    $config['username'] = 'appcldstorage';
    $config['password'] = 'Telkm#Sgma#27901.*#.!#';
    $config['authenticate'] = TRUE;

    // DEV MONGO ==================
    // $config['host'] = 'localhost'; 
    // $config['port'] = 27017;
    // $config['username'] = 'KangGorengan2030';
    // $config['password'] = 'Tahu!p154N9!b4kWaN!cH1R3NK!';
    // $config['authenticate'] = TRUE;
?>