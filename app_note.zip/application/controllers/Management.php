<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set("Asia/Jakarta");
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
use chriskacerguis\RestServer\RestController;

class Management extends RestController {

    function __construct() 
    {
	parent::__construct();
	$this->load->model('M_management');
    }

    public function login_post(){
        $_POST = $this->security->xss_clean($_POST);

        $config = [
            [
                'field' => 'nd',
                'label' => 'ND Number',
                'rules' => 'required',
                'errors' => [
                    'required' => 'ND Number is required!'
                ]
            ],
            [
                'field' => 'apikey',
                'label' => 'ApiKey',
                'rules' => 'required',
                'errors' => [
                    'required' => 'ApiKey is required!'
                ]
            ]
        ];

        $data = $this->input->get();
        $this->form_validation->set_data($data);
        $this->form_validation->set_rules($config);

        if($this->form_validation->run() == false){
            $this->response([
                'status' => false,
                'message' => $this->form_validation->error_array()
            ], 400);
        }
        else{
            $api_key = strtolower($_POST['apikey']); 
            $str = $_POST['nd'];
            $e_str = hash ( "sha256", $str );
            $apis = substr($e_str, 8, 8);
            
            if($api_key == $apis){
                $c_nd = $this->M_management->check_nd($_POST['nd']);
                if($c_nd == 0){
                    $this->response([
                        'code' => 0,
                        'status' => true,
                        'message' => 'ND not found!',
                        'data' => array()
                    ], 404);
                }
                else{
                    $res = $this->M_management->send_nd($_POST['nd'], strtolower($_POST['apikey']));
                    
                    if(!isset($res['code']))
                    {
                        $this->response([
                            'code' => 1,
                            'status' => true,
                            'message' => 'Success login',
                            'data' => $res
                        ], 200);
                    }
                    // flow baru
                    elseif(isset($res['code']) && $res['code'] == -1){
                        $this->response([
                            'code' => -1,
                            'status' => false,
                            'message' => 'Please register'
                        ], 200);	
                    }
                    elseif(isset($res['code']) && $res['code'] == -2){
                        $this->response([
                            'code' => -1,
                            'status'  => false,
                            'message' => 'Please register trial'
                        ], 200);
                    }
                    // end flow baru
                    elseif(isset($res['code']) && $res['code'] == 'IncorrectAttemptsLocked'){
                        $this->response([
                            'code' => -1,
                            'status' => false,
                            'message' => 'Account is locked!'
                        ], 200);	
                    }
                    else{
                        $this->response([
                            'code' => -1,
                            'status' => false,
                            'message' => $res['code'],
                        ], 200);
                    }
                }
            }
            else{
                $this->response([
                    'code' => -1,
                    'status' => false,
                    'message' => 'Invalid apikey!',
                    'data' => array()
                ], 201);
            }
        }
    }

    // api cek register
    public function check_stat_post(){
        $_POST = $this->security->xss_clean($_POST);

        $config = [
            [
                'field' => 'nd',
                'label' => 'ND Number',
                'rules' => 'required',
                'errors' => [
                    'required' => 'ND Number is required!'
                ]
            ]
        ];

        $data = $this->input->get();
        $this->form_validation->set_data($data);
        $this->form_validation->set_rules($config);

        if($this->form_validation->run() == false){
            $this->response([
                'status' => false,
                'message' => $this->form_validation->error_array()
            ], 400);
        }
        else{
            $nd = $_POST['nd'];
            $res_check = $this->M_management->check_register($nd);
            
            if($res_check == 1){
                $this->response([
                    'code' => 1,
                    'status' => true,
                    'message' => 'Registered'
                ], 200);
            }            
            elseif($res_check == -1){
                $this->response([
                    'code' => 1,
                    'status' => true,
                    'message' => 'Trial Registered'
                ], 200);
            }
            elseif($res_check == -2){
                $this->response([
                    'code' => -1,
                    'status' => false,
                    'message' => 'Trial Not Registered'
                ], 200);
            }
			elseif($res_check == 0){
                $this->response([
                    'code' => 0,
                    'status' => false,
                    'message' => 'Not Registered'
                ], 200);
            }
            else{
                $this->response([
                    'code' => -3,
                    'status' => false,
                    'message' => 'failed to connect to database'
                ], 500);
            }
        }
    }

    public function regis_usr_post()
    {
        $_POST = $this->security->xss_clean($_POST);
        
        $config = [
            [
                'field' => 'ND',
                'label' => 'ND',
                'rules' => 'required',
                'errors' => [
                    'required' => 'ND is required!'
                ]
            ],
            [
                'field' => 'email_indihome',
                'label' => 'Email Indihome',
                'rules' => 'required',
                'errors' => [
                    'required' => 'Email Indihome is required!'
                ]
            ],
            [
                'field' => 'fullname',
                'label' => 'Full Name',
                'rules' => 'required',
                'errors' => [
                    'required' => 'Full Name is required!'
                ]
            ],
            [
                'field' => 'apikey',
                'label' => 'Apikey',
                'rules' => 'required',
                'errors' => [
                    'required' => 'ApiKey is required!'
                ]
            ]
        ];

        $data = $this->input->get();
        $this->form_validation->set_data($data);
        $this->form_validation->set_rules($config);

        if($this->form_validation->run() == false){
            $this->response([
                'status' => false,
                'message' => $this->form_validation->error_array()
            ], 400);
        }
        else{
            $api_key = strtolower($_POST['apikey']);
            $str = $_POST['ND'];
            $e_str = hash("sha256", $str);
            $apis = substr($e_str, 8, 8);
            
            if($api_key == $apis){
                $r_pwd = bin2hex(openssl_random_pseudo_bytes(5));
                $time = DateTime::createFromFormat('U.u', microtime(true));
                $date = new DateTime();
                $sub_time =  $date->getTimestamp();
                $d_pwd = $this->M_management->encrypt_pwd($r_pwd);

                $format_dnow = date('Y-m-d H:i:s');
                $create_tmstmp = strtotime($format_dnow);

                $arr = array(
                    'ND' => $_POST['ND'],
                    'storage_email' => $_POST['ND'].'@email.com',
                    'addon_id' => '205',
                    'bundle_id' => '301',
                    'password' => json_decode($d_pwd),
                    'email_indihome' => $_POST['email_indihome'],
                    'status' => -1,
                    'fullname' => $_POST['fullname'],
                    'active_addon_from' => $sub_time,
                    'update_at' => $time,
                    'created_at' => $time,
                    'created_at_ihsmart' => $create_tmstmp,
                    'storage_id' => '',
                    'api_key' => '',
                    'login_time' => $time,
                    'device_token' => 'a',
                    'os' => 'Trial',
                    'unsubs_addon_from' => '',
                    'mountbit_auth' => ''
                );
                $res = $this->M_management->registration($arr);
                if($res == 1) 
                {   
                    $lgn_cloudike = $this->M_management->lgn_cloudike($_POST['ND'], $arr['password'], $_POST['fullname']);

                    if($lgn_cloudike == '0'){
                        $this->response([
                            'code' => 0,
                            'status' => false,
                            'message' => 'User Already Exists'
                        ], 400);
                    }
		    elseif($lgn_cloudike == '-1'){
                        $this->response([
                            'code' => -1,
                            'status' => false,
                            'message' => 'Success created user, but fail to updating storage'
                        ], 200);
                    }
                    else{
                        $upd_mongo = $this->M_management->upd_mongo($lgn_cloudike, $_POST['ND']);

                        if($upd_mongo == 1){
                            $this->response([
                                'code' => 1,
                                'status' => true,
                                'message' => 'Success created user',
                                'data' => array($lgn_cloudike)
                            ], 200);
                        }
                        else{
                            $this->response([
                                'code' => 0,
                                'status' => false,
                                'message' => 'Error created user',
                            ], 400);
                        }
                    }
                }
                elseif($res == -1){
                    $this->response([
                        'code' => -1,
                        'status' => false,
                        'message' => 'User already exist'
                    ], 200);
                }
		        elseif($res == -2)
                {
                    $this->response([
                        'code' => -2,
                        'status' => true,
                        'message' => 'Trial is expired'
                    ], 200);
                }
                elseif($res == 2)
                {
                    $this->response([
                        'code' => 2,
                        'status' => true,
                        'message' => 'User updated successfully'
                    ], 200);
                }
                elseif($res == 3){
                    $this->response([
                        'code' => 3,
                        'status' => true,
                        'message' => 'This user is registered already'
                    ], 200);
                }
                else {
                    $this->response([
                        'code' => 0,
                        'status' => false,
                        'message' => 'Failed to create user'
                    ], 400);
                }
            }
            else{
                $this->response([
                    'code' => 0,
                    'status' => false,
                    'message' => 'Apikey not matched!'
                ], 400);
            }
            
        }
    }
    
}

/* End of file Management.php */

?>