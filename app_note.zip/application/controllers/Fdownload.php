<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set("Asia/Jakarta");

class Fdownload extends CI_Controller {

    public function index(){
        $var['nd'] = $_GET['ND'];
        $this->load->view('firebase/firebase_download', $var);
    }
}

/* End of file Fdownload.php */

?>