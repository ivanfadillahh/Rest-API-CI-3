<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set("Asia/Jakarta");

class Fupload extends CI_Controller {

    public function index(){
        $var['nd'] = $_GET['ND'];
        $this->load->view('firebase/firebase_upload', $var);
    }

}

/* End of file Firebase.php */

?>