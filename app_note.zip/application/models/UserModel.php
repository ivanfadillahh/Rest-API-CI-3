<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserModel extends CI_model {
	
	private $database = 'ihsmart';
	private $collection = 'ND';
	private $conn;
	
	function __construct() {
		parent::__construct();
		$this->load->library('mongodb');
		$res = $this->conn = $this->mongodb->getConn();
	}

	function ct_usr($nd){
		try {
			$user = array(
				'ND' => $nd,
				'created_at' => date('Y-m-d H:i:s')
			);
			
			$query = new MongoDB\Driver\BulkWrite();
			$query->insert($user);
			
			$result = $this->conn->executeBulkWrite($this->database.'.'.$this->collection, $query);

			if($result->getInsertedCount() == 1) {
				return $res = true;
			}
			return $res = false;
		} 
        catch(MongoDB\Driver\Exception\RuntimeException $ex) {
			show_error('Error while saving users: ' . $ex->getMessage(), 500);
		}
	}

	// Credit admin
	function send_credits(){
		$arr = array(
			'email' => 'cloudstorage_admin@root.com',
            // 'password' => '6s3#$tIrE!nu2aZ4'
			'password' => 'qwerty123456'
		);
		return $arr;
	}

	// Login admin cloudike
	function log_adm_cloudike($nd, $pwd, $name){
		$curl = curl_init();
		
		$credits = $this->send_credits();

        curl_setopt_array($curl, array(
            // CURLOPT_URL => 'https://api.obscloud.mobilecloud.co.id/api/2/accounts/login/',
			CURLOPT_URL => 'https://api-tsigma-qa.cloudike.com/api/2/accounts/login/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('email' => $credits['email'],'password' => $credits['password']),
        ));

        $response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
			echo "cURL Error #:" . $err;
		} 
        else {
            // return $res = json_decode($response,true);
			$arr = json_decode($response, true);
			
			return $res = $this->ct_cloudike($arr['token'], $nd, $pwd, $name);
		}
	}

	// Create user cloudike
	function ct_cloudike($token, $nd, $pwd, $name){
		$curl = curl_init();

		curl_setopt_array($curl, array(
			// CURLOPT_URL => 'https://api.obscloud.mobilecloud.co.id
			CURLOPT_URL => 'https://api-tsigma-qa.cloudike.com/api/2/admin_resources/tenants/2/users',
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS => array('login' => 'email:'.$nd.'@email.com','password' => $pwd,'name' => $name),
			CURLOPT_HTTPHEADER => array(
				'Mountbit-Auth:'.$token
			),
		));

        $response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
			echo "cURL Error #:" . $err;
		} 
        else {
            $arr = json_decode($response, true);

			if(isset($arr['code']) && $arr['code'] == 'UserAlreadyExists'){
				return $res = '0';
			}
			else{
				return $res = $this->login_user($nd.'@email.com', $pwd);
			}		
        }
	}

	// Login user cloudike
	function login_user($eml, $pwd){
		$curl = curl_init();

		curl_setopt_array($curl, array(
			// CURLOPT_URL => 'https://api.obscloud.mobilecloud.co.id
			CURLOPT_URL => 'https://api-tsigma-qa.cloudike.com/api/2/accounts/login/',
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS => array('email' => $eml,'password' => $pwd),
		));
		$response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
			echo "cURL Error #:" . $err;
		} 
        else {
            return $res = json_decode($response,true);
		}
	}

	// Update DB Mongo
	function update_mongo($lg_cloudike, $nd)	
	{
		$storage_id = $lg_cloudike['userid'];
		$mill = round(microtime(true) * 1000);
		$api_key = hash('sha256', date('H:i:s.'.$mill));
		$token = $lg_cloudike['token'];
		
		try {
			$query = new MongoDB\Driver\BulkWrite();
			$query->update(['ND' => $nd], ['$set' => array('storage_id' => $storage_id, 'mountbit_auth' => $token)]);
			
			$result = $this->conn->executeBulkWrite($this->database.'.'.$this->collection, $query);
			
			if($result->getModifiedCount() == 1) 
			{
				return $res = true;
			}
			return $res = false;
		}
        catch(MongoDB\Driver\Exception\RuntimeException $ex) {
			show_error('Error while updating users: ' . $ex->getMessage(), 500);
		}
	}
	// End update db mongo
	
	function get_user_list() {
		try {
			$filter = [];
			$query = new MongoDB\Driver\Query($filter);
			
			$result = $this->conn->executeQuery($this->database.'.'.$this->collection, $query);
			return $result;
		} catch(MongoDB\Driver\Exception\RuntimeException $ex) {
			show_error('Error while fetching users: ' . $ex->getMessage(), 500);
		}
	}
	
	function get_user($_id) {
		try {
			$filter = ['_id' => new MongoDB\BSON\ObjectId($_id)];
			$query = new MongoDB\Driver\Query($filter);
			
			$result = $this->conn->executeQuery($this->database.'.'.$this->collection, $query);
			
			foreach($result as $user) {
				return $user;
			}
			return NULL;
		} 
        catch(MongoDB\Driver\Exception\RuntimeException $ex) {
			show_error('Error while fetching user: ' . $ex->getMessage(), 500);
		}
	}
	
	function create_user($name, $email) {
		try {
			$user = array(
				'name' => $name,
				'email' => $email
			);
			
			$query = new MongoDB\Driver\BulkWrite();
			$query->insert($user);
			
			$result = $this->conn->executeBulkWrite($this->database.'.'.$this->collection, $query);
			
			if($result == 1) {
				return TRUE;
			}
			
			return FALSE;
		} 
        catch(MongoDB\Driver\Exception\RuntimeException $ex) {
			show_error('Error while saving users: ' . $ex->getMessage(), 500);
		}
	}
	
	function update_user($_id, $name, $email) {
		try {
			$query = new MongoDB\Driver\BulkWrite();
			$query->update(['_id' => new MongoDB\BSON\ObjectId($_id)], ['$set' => array('name' => $name, 'email' => $email)]);
			
			$result = $this->conn->executeBulkWrite($this->database.'.'.$this->collection, $query);
			
			if($result == 1) {
				return TRUE;
			}
			
			return FALSE;
		}
        catch(MongoDB\Driver\Exception\RuntimeException $ex) {
			show_error('Error while updating users: ' . $ex->getMessage(), 500);
		}
	}
	
	function delete_user($_id) {
		try {
			$query = new MongoDB\Driver\BulkWrite();
			$query->delete(['_id' => new MongoDB\BSON\ObjectId($_id)]);
			
			$result = $this->conn->executeBulkWrite($this->database.'.'.$this->collection, $query);
			
			if($result == 1) {
				return TRUE;
			}
			
			return FALSE;
		} 
        catch(MongoDB\Driver\Exception\RuntimeException $ex) {
			show_error('Error while deleting users: ' . $ex->getMessage(), 500);
		}
	}
	
}
?>