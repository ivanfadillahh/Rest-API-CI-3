<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_dev extends CI_Model {

    

}

/* End of file M_dev.php */

?>