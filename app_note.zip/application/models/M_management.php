<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_management extends CI_Model {

    private $database = 'cloudstorage';
    private $collection = 'ND';
    private $conn;
    private $dbql;

    function __construct() {
		parent::__construct();
		$this->load->library('Mongodb');
		$this->conn = $this->mongodb->getConn();
        	$this->dbql = $this->load->database('mysql', TRUE);
	}

    function check_nd($nd)
    {
        $this->dbql->select('*');
        $this->dbql->from('nd');
        $this->dbql->where('nd', $nd);
        $query = $this->dbql->get();
        $this->dbql->close();
        return $query->num_rows();
    }

    function send_nd($nd,$api)
    {
        try {
	    $filter = ['ND' => $nd];
	    $query = new MongoDB\Driver\Query($filter);
           
	    $result = $this->conn->executeQuery($this->database.'.'.$this->collection, $query);

            if($result->isDead() == true){
                return $res = array(
                    'code' => 'null'
                );
            }
            else{
                foreach($result as $res){
                    $var = $res;
                }

                if((isset($var->status) && $var->status == 1) || isset($var->created_at_ihsmart)){
                    $d_now = date('Y-m-d H:i:s');

                    // hari ini
                    $cnv_now = date('Y-m-d H:i:s', strtotime($d_now));

                    // tanggal created
                    $cnv_end = date('Y-m-d H:i:s', $var->created_at_ihsmart);
                    $fix_end = date('Y-m-d H:i:s',strtotime($cnv_end . '+ 90 days'));

                    if($cnv_now > $fix_end)
                    {
                        if(isset($var->status) && $var->status == 1)
                        {
                            return $res = $this->decrypt($var);
                        }
                        elseif(isset($var->status) && $var->status == -1){
                            return $res = array(
                                'code' => -1
                            );
                        }
                    }
                    else{
                        return $res = $this->decrypt($var);
                    }
                }
                else{
                    return $res = array(
                        'code' => -2
                    );
                }  
            }
	    } 
        catch(MongoDB\Driver\Exception\RuntimeException $ex) 
        {
	    return $res = 'null';
	}
    }

    function decrypt($var)
    {
        $pass = $var->password;
        $em = $var->ND.'@email.com';
     
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://app.cloudstorage.co.id/api/decryptpass',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('pass' => $pass,'mode' => 'd'),
            CURLOPT_HTTPHEADER => array(
                'Cookie: identifier=6YB0b4vD8ZFqTY8w'
            ),
        ));

        $response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
			echo "cURL Error #:" . $err;
		} 
        else {
            $pw = json_encode($response);
            return $res = $this->log_cloudike(json_decode($pw),$em);
        }
    }

    function log_cloudike($pw,$em)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.obscloud.mobilecloud.co.id/api/2/accounts/login/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('email' => $em,'password' => $pw),
        ));

        $response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
			echo "cURL Error #:" . $err;
		} 
        else {
            return $res = json_decode($response,true);
        }
    }

    function check_register($var)
    {
        try {
            $filter = ['ND' => $var];
	    $query = new MongoDB\Driver\Query($filter);
            
            $result = $this->conn->executeQuery($this->database.'.'.$this->collection, $query);

            foreach($result as $res){
                $var = $res;
            }

            if(isset($var->status) && $var->status == 1){
                // if(isset($var->created_at_ihsmart)){
                //     return $r = 1;
                // }
                // else{
                //     return $r = -2;
                // }
                return $res = 1;
            }
            elseif(isset($var->status) && $var->status == -1){
                if(isset($var->created_at_ihsmart)){
                    return $r = -1;
                }
                else{
                    return $r = -2;
                }
            }
            else{
                return $r = 0;
            }
    	} 
        catch(MongoDB\Driver\Exception\RuntimeException $ex) 
        {
            //show_error('Error while fetching users: ' . $ex->getMessage(), 500);
	    return $r = -3; 
	    }
    }

    // encrypting password
    function encrypt_pwd($pass)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://app.cloudstorage.co.id/api/decryptpass',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('pass' => $pass,'mode' => 'e'),
            CURLOPT_HTTPHEADER => array(
                'Cookie: identifier=3svL0cUzLmWWLKb4'
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
	    echo "cURL Error #:" . $err;
	} 
        else 
        {
	    return $arr = json_encode($response, true);
	}
    }

    // registration to mongodb
    function registration($arr)
    {
        $sql = array(
            'nd' => $arr['ND']
        );

        $res = $this->dbql->insert('nd', $sql);
        if($res == true || $res == false)
	    {
            try 
            {
                $filter = ['ND' => $arr['ND']];
                $query = new MongoDB\Driver\Query($filter);
                
                $result = $this->conn->executeQuery($this->database.'.'.$this->collection, $query);

                foreach($result as $res)
                {
                    $var = $res;
                }

                if(!isset($var->status))
                {
                    $query = new MongoDB\Driver\BulkWrite();
                    $query->insert($arr);
        
                    $result = $this->conn->executeBulkWrite($this->database.'.'.$this->collection, $query);
                    
                    if($result->getInsertedCount() == 1) {
                        return $res = 1;
                    }
                    return $res = 0;
                }
                else{
                    if($var->status == 1){
                        return $res = 3;
                    }
                    else{
                        if(!isset($var->created_at_ihsmart))
                        {
                            $format_dnow = date('Y-m-d H:i:s');
                            $create_tmstmp = strtotime($format_dnow);
                            
                            $query = new MongoDB\Driver\BulkWrite();
                            $query->update(['ND' => $arr['ND']], ['$set' => array('created_at_ihsmart' => $create_tmstmp)]);
                
                            $result = $this->conn->executeBulkWrite($this->database.'.'.$this->collection, $query);
                            
                            if($result->getModifiedCount() == 1) 
                            {
                                return $res = 2;
                            }
                            return $res = 0;
                        }
                        else{
                            $d_now = date('Y-m-d H:i:s');

                            // hari ini
                            $cnv_now = date('Y-m-d H:i:s', strtotime($d_now));

                            // tanggal created
                            $cnv_end = date('Y-m-d H:i:s', $var->created_at_ihsmart);
                            $fix_end = date('Y-m-d H:i:s',strtotime($cnv_end . '+ 90 days'));
                
                            if($cnv_now > $fix_end){
                                return $res = -2;
                            }
                            else{
                                return $res = -1;
                            } 
                        }
                    } 
                }
            }
            catch(MongoDB\Driver\Exception\RuntimeException $ex)
            {
                return $res = 0;
            }
        }        
    }

    // auth admin
    function auth_admin(){
        $arr = array(
            'email' => 'cloudstorage_admin@root.com',
            'password' => '6s3#$tIrE!nu2aZ4'
        );
        return $arr;
    }

    // login admin cloudike
    function lgn_cloudike($nd, $pwd, $name)
    {
        $curl = curl_init();
		
	$credits = $this->auth_admin();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.obscloud.mobilecloud.co.id/api/2/accounts/login/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('email' => $credits['email'],'password' => $credits['password']),
        ));

        $response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
	    echo "cURL Error #:" . $err;
	} 
        else 
        {
	    $arr = json_decode($response, true);
            return $res = $this->decrypt_pwd_cloudike($arr['token'], $nd, $pwd, $name);
	}
    }

    // decrypt khusus cloudike
    function decrypt_pwd_cloudike($token, $nd, $pwd, $name)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://app.cloudstorage.co.id/api/decryptpass',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('pass' => $pwd,'mode' => 'd'),
            CURLOPT_HTTPHEADER => array(
                'Cookie: identifier=6YB0b4vD8ZFqTY8w'
            ),
        ));

        $response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
	    echo "cURL Error #:" . $err;
	} 
        else {
            $pw = json_encode($response);
            return $res = $this->crt_user($token, $nd, json_decode($pw), $name);
        }
    }

    // create user cloudike
    function crt_user($token, $nd, $pwd, $name)
    {
        $curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => 'https://api.obscloud.mobilecloud.co.id/api/2/admin_resources/tenants/2/users',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'POST',
		CURLOPT_POSTFIELDS => array('login' => 'email:'.$nd.'@email.com','password' => $pwd,'name' => $name),
		CURLOPT_HTTPHEADER => array(
			'Mountbit-Auth:'.$token
		),
	));

        $response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
	    echo "cURL Error #:" . $err;
	} 
        else {
            $arr = json_decode($response, true);

	    if(isset($arr['code']) && $arr['code'] == 'UserAlreadyExists'){
		return $res = '0';
	    }
	    else{
		return $res = $this->lgn_user($nd.'@email.com', $pwd, $token);
	    }		
        }
    }

    // login user cloudike
    function lgn_user($eml, $pwd, $token)
    {
        $curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => 'https://api.obscloud.mobilecloud.co.id/api/2/accounts/login/',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'POST',
		CURLOPT_POSTFIELDS => array('email' => $eml,'password' => $pwd),
	));
	$response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
	    echo "cURL Error #:" . $err;
	} 
        else {
            //return $res = json_decode($response,true);
	    $res = json_decode($response,true);
            $up_storage = $this->update_storage_user($token, $res['userid']);
            if($up_storage == 1){
                return $res;
            }
            else{
                return $var = '-1';
            }
	}
    }

    // update storage user
    function update_storage_user($token, $id)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.obscloud.mobilecloud.co.id/api/2/admin_resources/tenants/2/users/'.$id.'/fs/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'PATCH',
            CURLOPT_POSTFIELDS => array('hard_quota_size' => '16106127360','quota_size' => '16106127360'),
            CURLOPT_HTTPHEADER => array(
                'Mountbit-Auth:'.$token
            ),
        ));

        $response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
			echo "cURL Error #:" . $err;
		} 
        else {
            $res = json_decode($response,true);
            if(isset($res['quota_size']) && isset($res['hard_quota_size'])){
                return $res = 1;
            }else{
                return $res = 0;
            }
        }
    }
    // end update user storage

    // Update DB Mongo
    function upd_mongo($lg_cloudike, $nd)	
    {
	$storage_id = $lg_cloudike['userid'];
	$mill = round(microtime(true) * 1000);
	$api_key = hash('sha256', date('H:i:s.'.$mill));
	$token = $lg_cloudike['token'];
		
	try {
	    $query = new MongoDB\Driver\BulkWrite();
	    $query->update(['ND' => $nd], ['$set' => array('storage_id' => $storage_id, 'mountbit_auth' => $token)]);
			
	    $result = $this->conn->executeBulkWrite($this->database.'.'.$this->collection, $query);
			
	    if($result->getModifiedCount() == 1) 
	    {
		return $res = true;
	    }
	    return $res = false;
	}
        catch(MongoDB\Driver\Exception\RuntimeException $ex) {
	    //show_error('Error while updating users: ' . $ex->getMessage(), 500);
	    return $res = false;
	}
    }
}

/* End of file M_management.php */

?>
